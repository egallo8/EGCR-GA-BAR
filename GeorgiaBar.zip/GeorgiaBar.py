import webbrowser, sys, pyperclip
from selenium import webdriver 
from selenium.webdriver.common.action_chains import ActionChains ##hover
from selenium.webdriver.common.keys import Keys #import for enter key
from selenium.webdriver.common.by import By #(By.CLASS_NAME, 'k-textbox'))
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select#sys.argv
# Change this if you need
browser = webdriver.Chrome("C:\\Users\\GalloPad\\Desktop\\GeorgiaBar\\chromedriver")
                           #'C:\\Users\\ElizabethGallo\\Desktop\\Selenium\\Selenium\\chromedriver'

browser.get("https://www.gabar.org")

fullName = pyperclip.paste()
fullName = list(fullName.split(" "))
print (fullName)
firstName = fullName[0]
lastName = fullName[-1]
print (firstName)
print (lastName)

first = browser.find_element_by_id("FirstName").send_keys(firstName)
last = browser.find_element_by_id("LastName").send_keys(lastName)
#dailyJobExport = ActionChains(googleBrowser).click(clickCopyOfStaff).perform()

search = browser.find_element_by_xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div[2]/form/div[2]/button")
click = ActionChains(browser).click(search).perform()


                
